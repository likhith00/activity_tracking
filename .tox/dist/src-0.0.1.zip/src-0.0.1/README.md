This repo is MLOPS implementation on activity tracking dataset.
