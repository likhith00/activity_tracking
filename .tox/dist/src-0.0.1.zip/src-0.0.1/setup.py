from setuptools import setup, find_packages

setup(
      name = "src",
      version = "0.0.1",
      description="Its mlops implementation of activity tracking dataset",
      author = "likhith prudhivi",
      packages = find_packages(),
      license = "MIT",
)